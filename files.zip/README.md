# 🎮 Shampis Trial Key Bot

Discord bot for automatic trial key distribution for Shampis Black Ops 7.

---

## 📋 Features

- Button-based key claiming in a dedicated channel
- 1 key per Discord account (tracked by user ID)
- Keys sent via DM automatically
- Keys file updated automatically (no duplicates)
- Admin commands to manage keys and users
- Error handling: DMs disabled, no keys left, already claimed

---

## ⚙️ Installation

### 1. Prerequisites

- Python 3.10 or higher
- A Discord bot token

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Create your Discord bot

1. Go to https://discord.com/developers/applications
2. Click **New Application**
3. Go to **Bot** tab → **Add Bot**
4. Copy your **Token**
5. Enable **Server Members Intent** and **Message Content Intent**
6. Go to **OAuth2 → URL Generator**
7. Select scopes: `bot`, `applications.commands`
8. Select permissions: `Send Messages`, `Read Messages`, `Embed Links`
9. Copy the URL and invite the bot to your server

### 4. Configure the bot

Edit `config.py`:

```python
BOT_TOKEN = "YOUR_BOT_TOKEN_HERE"        # Your bot token
TRIAL_CHANNEL_NAME = "free-trial-essai"  # Channel name
BUTTON_LABEL = "External Cheat BO7"      # Button text
```

### 5. Add your trial keys

Edit `keys.txt` and add your KeyAuth keys, one per line:

```
XXXX-YYYY-ZZZZ-1111
XXXX-YYYY-ZZZZ-2222
XXXX-YYYY-ZZZZ-3333
```

### 6. Run the bot

```bash
python bot.py
```

### 7. Setup the channel message

In your Discord server, type:
```
!setup
```
This posts the embed with the claim button in your configured channel.

---

## 🛠️ Admin Commands

| Command | Description |
|---|---|
| `!setup` | Post the trial button in the configured channel |
| `!keys` | Check how many keys are remaining |
| `!addkeys KEY1\nKEY2` | Add new keys to the pool |
| `!resetuser @user` | Allow a user to claim a key again |

---

## 📁 File Structure

```
discord_bot/
├── bot.py          # Main bot file
├── config.py       # Configuration
├── keys.txt        # Available trial keys (one per line)
├── database.json   # Auto-generated, tracks claimed keys
├── requirements.txt
└── README.md
```

---

## 🌐 Hosting on a VPS

```bash
# Install screen to keep bot running
sudo apt install screen

# Start a screen session
screen -S shampisbot

# Run the bot
python bot.py

# Detach from screen: Ctrl+A then D
# Reattach: screen -r shampisbot
```

---

## ❓ Troubleshooting

**Bot doesn't respond to !setup**
- Make sure you have Administrator permission
- Check the channel name in config.py matches exactly

**User says they didn't receive DM**
- They need to enable DMs: User Settings → Privacy & Safety → Allow DMs from server members

**Keys not loading**
- Make sure keys.txt exists and has one key per line
- No empty lines at the end of the file
